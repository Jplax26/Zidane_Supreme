-- StarterPlayerScripts/ZidaneSupreme/Client (LocalScript)
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("ZidaneSupreme")
local Config = require(Shared.Config)
local Remotes = require(Shared.Remotes)
local UI = require(script.Parent.UI)
local Walker = require(script.Parent.Walker)

local ui = UI.build(Remotes, Config)
Walker.start(Remotes)
Remotes.State.OnClientEvent:Connect(ui.update)
Remotes.Command:FireServer("Sync") -- minta status awal
