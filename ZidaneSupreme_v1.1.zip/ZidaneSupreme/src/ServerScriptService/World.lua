-- ServerScriptService/ZidaneSupreme/World (ModuleScript)
-- Memastikan objek Workspace ada. Kalau belum kamu buat sendiri, dibuat otomatis (penanda neon).
-- Kamu boleh memindah/menambah: Checkpoints & DropLocations berisi BasePart (nama = pilihan di UI).
local World = {}

local function folder(name)
	local f = workspace:FindFirstChild(name)
	if not f then
		f = Instance.new("Folder")
		f.Name = name
		f.Parent = workspace
	end
	return f
end

local function marker(parent, name, pos, color)
	local p = Instance.new("Part")
	p.Name, p.Anchored, p.CanCollide = name, true, false
	p.Size, p.Position, p.Color = Vector3.new(6, 1, 6), pos, color
	p.Material, p.Transparency = Enum.Material.Neon, 0.4
	p.Parent = parent
end

function World.ensure()
	World.Blocks = folder("FarmBlocks")
	World.Drops = folder("FarmDrops")
	World.Checkpoints = folder("Checkpoints")
	World.DropLocations = folder("DropLocations")
	-- GridOrigin: sisi BAWAH part ini = permukaan tanah, posisinya = sudut grid plot pertama
	if not workspace:FindFirstChild("GridOrigin") then
		marker(workspace, "GridOrigin", Vector3.new(-60, 0.5, -60), Color3.fromRGB(139, 92, 246))
	end
	if not World.Checkpoints:FindFirstChildWhichIsA("BasePart") then
		marker(World.Checkpoints, "Checkpoint1", Vector3.new(-90, 0.5, -90), Color3.fromRGB(52, 211, 153))
	end
	if not World.DropLocations:FindFirstChildWhichIsA("BasePart") then
		marker(World.DropLocations, "Drop1", Vector3.new(-90, 0.5, -70), Color3.fromRGB(239, 68, 68))
	end
end

return World
