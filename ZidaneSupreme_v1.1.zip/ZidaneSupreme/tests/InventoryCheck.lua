-- Cek cepat logika Inventory + Auto Drop. Jalankan di Command Bar Studio (View > Command Bar):
--   require(game.ServerScriptService.ZidaneSupreme.Inventory) tidak perlu; cukup paste file ini.
local Inventory = require(game.ServerScriptService.ZidaneSupreme.Inventory)
local p = {} -- pemain palsu; Inventory hanya memakai p sebagai key
Inventory.init(p)

assert(Inventory.add(p, "Gem", 1) == 1)
assert(Inventory.add(p, "Block", 1) == 1)
assert(Inventory.add(p, "Seed", 250) == 200, "Seed harus mentok 200 saat Gem+Block memakai 2 dari 3 slot")
assert(Inventory.room(p, "Seed") == 0)
assert(Inventory.needsDrop(p), "Seed 200 + inventory penuh -> harus drop")
assert(Inventory.remove(p, "Seed", 200))
assert(Inventory.get(p, "Gem") == 1 and Inventory.get(p, "Block") == 1, "Gem/Block tidak boleh ikut terbuang")
assert(not Inventory.needsDrop(p))
print("ZIDANE SUPREME: Inventory check OK")
