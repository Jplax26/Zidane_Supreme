-- ServerScriptService/ZidaneSupreme/Main (Script)
local Players = game:GetService("Players")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("ZidaneSupreme")
local Remotes = require(Shared.Remotes) -- harus di-require dulu supaya RemoteEvents terbentuk
local World = require(script.Parent.World)
local Farm = require(script.Parent.Farm)

World.ensure()

Remotes.Command.OnServerEvent:Connect(Farm.command)
Remotes.PathFailed.OnServerEvent:Connect(Farm.pathFailed)
Players.PlayerAdded:Connect(Farm.add)
Players.PlayerRemoving:Connect(Farm.remove)
for _, p in Players:GetPlayers() do task.spawn(Farm.add, p) end
