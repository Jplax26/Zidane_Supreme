-- StarterPlayerScripts/ZidaneSupreme/Walker (ModuleScript)
-- Berjalan ke tujuan dari server memakai PathfindingService + Humanoid:MoveTo.
-- Client TIDAK memutuskan apa pun soal farming; hanya berjalan dan melapor jika gagal.
local PFS = game:GetService("PathfindingService")
local Players = game:GetService("Players")

local Walker = {}
local player = Players.LocalPlayer
local current = 0 -- id tujuan aktif; walk lama berhenti sendiri jika id berubah

local function alive()
	local c = player.Character
	local h = c and c:FindFirstChildOfClass("Humanoid")
	local r = c and c:FindFirstChild("HumanoidRootPart")
	if h and r and h.Health > 0 then return h, r end
end

function Walker.start(Remotes)
	local function walk(id, goal)
		for _ = 1, 3 do -- maksimal 3 percobaan, lalu lapor gagal (tidak ada loop tak terbatas)
			local hum, root = alive()
			if not hum or current ~= id then return end
			local path = PFS:CreatePath({ AgentRadius = 1.5, AgentHeight = 5, AgentCanJump = true })
			local ok = pcall(function() path:ComputeAsync(root.Position, goal) end)
			if ok and path.Status == Enum.PathStatus.Success then
				local arrived = true
				for _, wp in path:GetWaypoints() do
					if current ~= id or hum.Health <= 0 then return end
					if wp.Action == Enum.PathWaypointAction.Jump then hum.Jump = true end
					hum:MoveTo(wp.Position)
					if not hum.MoveToFinished:Wait() then arrived = false break end
				end
				if arrived then return end
			end
			task.wait(0.3)
		end
		if current == id then Remotes.PathFailed:FireServer(id) end
	end

	Remotes.Goto.OnClientEvent:Connect(function(id, goal)
		current = id
		if typeof(goal) == "Vector3" then
			task.spawn(walk, id, goal)
		else
			local hum, root = alive()
			if hum then hum:MoveTo(root.Position) end -- berhenti
		end
	end)
end

return Walker
