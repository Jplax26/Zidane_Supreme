-- ReplicatedStorage/ZidaneSupreme/Remotes (ModuleScript)
-- Server membuat RemoteEvents, client menunggunya. Pakai: Remotes.Command, Remotes.State, dst.
--   Command    C->S  ("Start"|"Stop"|"Toggle"|"Grid"|"Pad"|"Sync", ...)
--   State      S->C  tabel status untuk UI
--   Goto       S->C  (id, Vector3?)  server menentukan tujuan, client yang berjalan
--   PathFailed C->S  (id)            client melapor Pathfinding gagal
local RunService = game:GetService("RunService")

local names = { "Command", "State", "Goto", "PathFailed" }
local events

if RunService:IsServer() then
	events = Instance.new("Folder")
	events.Name = "Events"
	for _, n in names do
		local r = Instance.new("RemoteEvent")
		r.Name = n
		r.Parent = events
	end
	events.Parent = script.Parent
else
	events = script.Parent:WaitForChild("Events")
end

return setmetatable({}, { __index = function(_, k) return events:WaitForChild(k) end })
