-- ServerScriptService/ZidaneSupreme/Inventory (ModuleScript)
-- Inventory per pemain, hanya hidup di server. Client tidak bisa mengubahnya.
-- ponytail: tidak disimpan ke DataStore (belum diminta). Upgrade: simpan snapshot() saat PlayerRemoving.
local Config = require(game:GetService("ReplicatedStorage"):WaitForChild("ZidaneSupreme").Config)

local Inv = {}
local data = {}

function Inv.init(p) data[p] = { Seed = 0, Gem = 0, Block = 0 } end
function Inv.clear(p) data[p] = nil end
function Inv.get(p, kind) return data[p] and data[p][kind] or 0 end

function Inv.snapshot(p)
	local d = data[p]
	return d and { Seed = d.Seed, Gem = d.Gem, Block = d.Block } or { Seed = 0, Gem = 0, Block = 0 }
end

local function slotsUsed(d)
	local n = 0
	for k, c in d do n += math.ceil(c / Config.Inventory.Stack[k]) end
	return n
end

-- sisa jumlah yang masih muat untuk jenis item ini (slot kosong + sisa stack sendiri)
function Inv.room(p, kind)
	local d = data[p]
	local stack = d and Config.Inventory.Stack[kind]
	if not stack then return 0 end
	local slots = Config.Inventory.Slots - (slotsUsed(d) - math.ceil(d[kind] / stack))
	return math.max(0, slots * stack - d[kind])
end

function Inv.add(p, kind, n)
	local added = math.clamp(n, 0, Inv.room(p, kind))
	if added > 0 then data[p][kind] += added end
	return added
end

function Inv.remove(p, kind, n)
	local d = data[p]
	if not d or not d[kind] or n <= 0 or d[kind] < n then return false end
	d[kind] -= n
	return true
end

function Inv.needsDrop(p)
	return Inv.get(p, "Seed") >= Config.SeedDropAt and Inv.room(p, "Seed") < 1
end

return Inv
