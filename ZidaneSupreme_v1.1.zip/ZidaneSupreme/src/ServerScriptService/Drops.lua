-- ServerScriptService/ZidaneSupreme/Drops (ModuleScript)
-- Drop dimiliki pemain: attribute Owner + disimpan di FarmDrops/<UserId>. Collect hanya membaca folder
-- milik sendiri DAN mengecek Owner lagi, jadi pemain lain tidak bisa mengambil.
local Debris = game:GetService("Debris")
local Config = require(game:GetService("ReplicatedStorage"):WaitForChild("ZidaneSupreme").Config)
local World = require(script.Parent.World)
local Inventory = require(script.Parent.Inventory)

local Drops = {}
local colors = {
	Seed = Color3.fromRGB(90, 200, 90),
	Gem = Color3.fromRGB(80, 170, 255),
	Block = Color3.fromRGB(150, 105, 60),
}

local function folder(id)
	local f = World.Drops:FindFirstChild(tostring(id))
	if not f then
		f = Instance.new("Folder")
		f.Name = tostring(id)
		f.Parent = World.Drops
	end
	return f
end

-- ownerId 0 = tidak dimiliki siapa pun (Seed yang dijatuhkan di DropLocation)
function Drops.spawn(ownerId, pos, kind, amount)
	local part = Instance.new("Part")
	part.Name, part.Shape, part.Size = kind, Enum.PartType.Ball, Vector3.one * 1.5
	part.Anchored, part.CanCollide, part.Color = true, false, colors[kind]
	part.Position = pos + Vector3.new(math.random(-20, 20) / 10, 1, math.random(-20, 20) / 10)
	part:SetAttribute("Owner", ownerId)
	part:SetAttribute("Kind", kind)
	part:SetAttribute("Amount", amount)
	part.Parent = folder(ownerId)
	Debris:AddItem(part, Config.DropLifetime)
end

-- ponytail: scan folder milik sendiri tiap tick; cukup untuk ratusan drop. Upgrade: spatial query.
function Drops.collect(p, pos)
	local f = World.Drops:FindFirstChild(tostring(p.UserId))
	if not f then return end
	for _, d in f:GetChildren() do
		if d:GetAttribute("Owner") == p.UserId and (d.Position - pos).Magnitude <= Config.CollectRange then
			local n = d:GetAttribute("Amount")
			local added = Inventory.add(p, d:GetAttribute("Kind"), n)
			if added >= n then d:Destroy() elseif added > 0 then d:SetAttribute("Amount", n - added) end
		end
	end
end

-- HANYA Seed yang dibuang; Gem dan Block tidak disentuh.
function Drops.dropSeeds(p, pos)
	local n = Inventory.get(p, "Seed")
	if n <= 0 or not Inventory.remove(p, "Seed", n) then return 0 end
	Drops.spawn(0, pos, "Seed", n)
	return n
end

function Drops.release(p)
	local f = World.Drops:FindFirstChild(tostring(p.UserId))
	if f then f:Destroy() end
end

return Drops
