-- ServerScriptService/ZidaneSupreme/Farm (ModuleScript)
-- Otak sistem: satu sesi per pemain, satu loop per sesi (berhenti saat Stop / pemain keluar).
-- Server memutuskan MODE (Drop > Checkpoint > Farm), memilih target, dan memvalidasi jarak + cooldown hit.
-- Client hanya berjalan ke tujuan yang dikirim server (Goto) dan melapor jika Pathfinding gagal.
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("ZidaneSupreme")
local Config = require(Shared.Config)
local Remotes = require(Shared.Remotes)
local World = require(script.Parent.World)
local Inventory = require(script.Parent.Inventory)
local Blocks = require(script.Parent.Blocks)
local Drops = require(script.Parent.Drops)

local Farm = {}
local sessions = {}
local TOGGLES = { AutoFarm = true, AutoCollect = true, AutoCheckpoint = true, AutoDrop = true }

local function newSession()
	return {
		Running = false, Token = 0, Status = "Stopped",
		Toggles = { AutoFarm = true, AutoCollect = true, AutoCheckpoint = true, AutoDrop = true },
		Settings = { Count = Config.Grid.Count, Spacing = Config.Grid.Spacing },
		Skip = {}, Target = nil, TargetId = 0, Fails = 0, CpUntil = nil,
		LastHit = 0, LastCmd = 0, LastGrid = 0, LastPush = 0,
	}
end

local function push(p, s, force)
	local now = os.clock()
	if not force and now - s.LastPush < 0.4 then return end
	s.LastPush = now
	Remotes.State:FireClient(p, {
		Running = s.Running, Status = s.Status, Toggles = s.Toggles, Settings = s.Settings,
		Inv = Inventory.snapshot(p), Blocks = Blocks.count(p), Total = s.Settings.Count * s.Settings.Count,
	})
end

local function charRoot(p)
	local c = p.Character
	local h = c and c:FindFirstChildOfClass("Humanoid")
	local r = c and c:FindFirstChild("HumanoidRootPart")
	if h and r and h.Health > 0 then return r end
end

local function flat(a, b) return Vector3.new(a.X - b.X, 0, a.Z - b.Z).Magnitude end

local function pickPad(folder, name)
	local f = name and folder:FindFirstChild(name)
	if f and f:IsA("BasePart") then return f end
	return folder:FindFirstChildWhichIsA("BasePart")
end

local function setTarget(p, s, kind, pos, part)
	s.TargetId += 1
	s.Target = { Kind = kind, Pos = pos, Part = part, Since = os.clock() }
	Remotes.Goto:FireClient(p, s.TargetId, pos)
end

local function clearTarget(p, s)
	if s.Target then
		s.Target = nil
		s.TargetId += 1
		Remotes.Goto:FireClient(p, s.TargetId, nil)
	end
end

-- Target gagal (Pathfinding gagal / timeout). Block di-skip sementara; checkpoint/drop gagal 3x -> Stop.
local function failTarget(p, s)
	local t = s.Target
	if not t then return end
	s.Fails += 1
	if t.Kind == "Block" then
		s.Skip[t.Part] = os.clock() + Config.SkipTime
	elseif s.Fails >= 3 then
		Farm.stop(p, "Path gagal ke " .. t.Kind)
		return
	end
	clearTarget(p, s)
end

local function step(p, s)
	local root = charRoot(p)
	if not root then -- mati / respawn: lepas target, client akan dikirim target baru setelah respawn
		s.Target = nil
		s.Status = "Menunggu respawn"
		return
	end
	local T, set = s.Toggles, s.Settings
	if T.AutoCollect then Drops.collect(p, root.Position) end

	local mode = "Idle"
	local threshold = math.min(Config.Checkpoint.Below, (set.Count * set.Count) // 2)
	if T.AutoDrop and Inventory.needsDrop(p) then
		mode = "Drop"
	elseif s.CpUntil or (T.AutoCheckpoint and Blocks.count(p) < threshold) then
		mode = "Checkpoint" -- s.CpUntil terisi = sedang PAUSE di checkpoint
	elseif T.AutoFarm then
		mode = "Farm"
	end

	if s.Target and s.Target.Kind ~= (mode == "Farm" and "Block" or mode) then clearTarget(p, s) end

	if mode == "Idle" then
		s.Status = "Idle"
		return
	end

	if mode == "Farm" then
		local t = s.Target
		if t and not t.Part.Parent then clearTarget(p, s) t = nil end
		if t and os.clock() - t.Since > Config.TargetTimeout then failTarget(p, s) return end
		if not t then
			local b = Blocks.nearest(p, root.Position, s.Skip)
			if not b then s.Status = "Tidak ada block" return end
			-- berdiri di koridor antar baris (bukan di dalam block) supaya Pathfinding valid
			local stand = Vector3.new(b.Position.X, b.Position.Y - Config.Grid.BlockSize / 2 + 3, b.Position.Z + set.Spacing / 2)
			setTarget(p, s, "Block", stand, b)
			t = s.Target
		end
		s.Status = "Farming"
		if (root.Position - t.Part.Position).Magnitude <= Config.Hit.Range and os.clock() - s.LastHit >= Config.Hit.Cooldown then
			s.LastHit = os.clock()
			if Blocks.hit(p, t.Part, Config.Hit.Damage) then
				s.Fails = 0
				s.Target = nil -- target baru dipilih tick berikutnya (client tidak dihentikan)
				if T.AutoCollect then Drops.collect(p, root.Position) end -- langsung ambil drop
			end
		end
		return
	end

	-- Checkpoint / Drop
	local isCp = mode == "Checkpoint"
	local pad = pickPad(isCp and World.Checkpoints or World.DropLocations, isCp and s.Settings.Checkpoint or s.Settings.DropLocation)
	if not pad then
		Farm.stop(p, (isCp and "Checkpoint" or "DropLocation") .. " tidak ada")
		return
	end
	local goal = pad.Position + Vector3.new(0, 3, 0)

	if flat(root.Position, goal) <= Config.ArriveRange then
		clearTarget(p, s)
		s.Fails = 0
		if isCp then
			s.CpUntil = s.CpUntil or (os.clock() + Config.Checkpoint.Wait)
			local left = s.CpUntil - os.clock()
			if left > 0 then
				s.Status = ("Pause di checkpoint (%ds)"):format(math.ceil(left))
				return
			end
			s.CpUntil, s.Skip = nil, {} -- RESUME: isi ulang grid lalu lanjut farming
			if Blocks.build(p, set.Count, set.Spacing) == 0 then Farm.stop(p, "GridOrigin tidak ada") return end
			s.Status = "Resume farming"
		else
			s.Status = ("Drop %d Seed"):format(Drops.dropSeeds(p, pad.Position + Vector3.new(0, 1, 0)))
		end
		return
	end

	local t = s.Target
	if t and os.clock() - t.Since > Config.TargetTimeout then failTarget(p, s) return end
	if not t then setTarget(p, s, mode, goal) end
	s.Status = isCp and "Menuju checkpoint" or "Menuju lokasi drop"
end

function Farm.start(p)
	local s = sessions[p]
	if not s or s.Running then return end
	s.Running, s.Fails, s.Skip = true, 0, {}
	s.Token += 1
	local token = s.Token
	task.spawn(function()
		-- loop pasti berhenti: Stop (Running=false), Start ulang (Token beda), atau pemain keluar
		while s.Running and s.Token == token and p.Parent do
			local ok, err = pcall(step, p, s)
			if not ok then
				warn("[ZIDANE SUPREME] error:", err)
				Farm.stop(p, "Error internal")
			end
			push(p, s)
			task.wait(Config.Tick)
		end
	end)
	push(p, s, true)
end

function Farm.stop(p, reason)
	local s = sessions[p]
	if not s then return end
	s.Running, s.CpUntil = false, nil
	clearTarget(p, s)
	s.Status = reason or "Stopped"
	push(p, s, true)
end

function Farm.add(p)
	local s = newSession()
	sessions[p] = s
	Inventory.init(p)
	Blocks.assignSlot(p)
	Blocks.build(p, s.Settings.Count, s.Settings.Spacing)
end

function Farm.remove(p)
	local s = sessions[p]
	if s then s.Running = false end
	sessions[p] = nil
	Inventory.clear(p)
	Blocks.release(p)
	Drops.release(p)
end

-- Semua input client divalidasi di sini: tipe, whitelist, clamp, rate limit.
function Farm.command(p, action, a, b)
	local s = sessions[p]
	if not s or type(action) ~= "string" then return end
	local now = os.clock()
	if now - s.LastCmd < Config.CommandCooldown then return end
	s.LastCmd = now

	if action == "Start" then
		Farm.start(p)
	elseif action == "Stop" then
		Farm.stop(p)
	elseif action == "Toggle" then
		if type(a) == "string" and TOGGLES[a] and type(b) == "boolean" then s.Toggles[a] = b end
	elseif action == "Grid" then
		local g = Config.Grid
		if type(a) == "number" and type(b) == "number" and a == a and b == b and now - s.LastGrid >= Config.GridCooldown then
			s.LastGrid = now
			s.Settings.Count = math.floor(math.clamp(a, g.MinCount, g.MaxCount))
			s.Settings.Spacing = math.floor(math.clamp(b, g.MinSpacing, g.MaxSpacing))
			s.Skip, s.Target = {}, nil
			Blocks.build(p, s.Settings.Count, s.Settings.Spacing)
		end
	elseif action == "Pad" then
		local folder = (a == "Checkpoint" and World.Checkpoints) or (a == "DropLocation" and World.DropLocations)
		if folder and type(b) == "string" then
			local pad = folder:FindFirstChild(b)
			if pad and pad:IsA("BasePart") then s.Settings[a] = b end
		end
	end -- "Sync" tidak butuh aksi: cukup push di bawah
	push(p, s, true)
end

function Farm.pathFailed(p, id)
	local s = sessions[p]
	if s and s.Target and type(id) == "number" and id == s.TargetId then failTarget(p, s) end
end

return Farm
