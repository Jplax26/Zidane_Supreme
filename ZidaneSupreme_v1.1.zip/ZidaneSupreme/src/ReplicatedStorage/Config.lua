-- ReplicatedStorage/ZidaneSupreme/Config (ModuleScript)
-- Semua angka penting ada di sini. Server membaca ini sebagai sumber kebenaran.
return {
	Name = "ZIDANE SUPREME",
	Version = "v1.1",

	Grid = {
		Count = 8,        -- default N x N block
		Spacing = 9,      -- jarak antar pusat block (stud); BlockSize 4 + gap 5 agar karakter muat lewat
		BlockSize = 4,
		MinCount = 3, MaxCount = 12,
		MinSpacing = 8, MaxSpacing = 12,
		PlotStride = 150, -- jarak antar plot pemain (tiap pemain punya grid sendiri)
		PlotsPerRow = 4,
	},

	Block = { HP = 5 },
	Hit = { Damage = 1, Cooldown = 0.35, Range = 9 },
	Drops = { Seed = 1, Gem = 1, Block = 1 }, -- jatuh per block hancur
	DropLifetime = 120,
	CollectRange = 12,

	-- Inventory berbasis slot: tiap slot menampung 1 jenis item sampai batas stack.
	Inventory = { Slots = 3, Stack = { Seed = 200, Gem = 99, Block = 99 } },
	SeedDropAt = 200, -- Auto Drop aktif jika Seed >= ini DAN tidak ada ruang untuk 1 Seed lagi

	Checkpoint = { Below = 10, Wait = 6 }, -- block tersisa < Below -> ke checkpoint, pause Wait detik, grid diisi ulang
	ArriveRange = 6,
	TargetTimeout = 30, -- detik; target tidak tercapai -> dianggap gagal
	SkipTime = 30,      -- block yang gagal dijangkau di-skip selama ini
	Tick = 0.25,
	CommandCooldown = 0.1,
	GridCooldown = 1,
}
