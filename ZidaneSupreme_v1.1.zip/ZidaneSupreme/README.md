# ZIDANE SUPREME v1.1

Sistem auto farm **server-authoritative** untuk game Roblox milik sendiri (Roblox Studio + Luau).
Auto Farm, Auto Collect, Auto Checkpoint, Auto Drop Seed, dan UI gaming modern dengan sidebar.

## Struktur

| Folder repo | Lokasi di Roblox Studio | Isi |
|---|---|---|
| `src/ReplicatedStorage` | `ReplicatedStorage/ZidaneSupreme` (Folder) | `Config`, `Remotes` (ModuleScript) |
| `src/ServerScriptService` | `ServerScriptService/ZidaneSupreme` (Folder) | `Main` (Script), `World`, `Inventory`, `Drops`, `Blocks`, `Farm` (ModuleScript) |
| `src/StarterPlayerScripts` | `StarterPlayer/StarterPlayerScripts/ZidaneSupreme` (Folder) | `Client` (LocalScript), `UI`, `Walker` (ModuleScript) |
| `tests/InventoryCheck.lua` | Command Bar Studio | cek cepat logika inventory |

Workspace (`FarmBlocks`, `FarmDrops`, `Checkpoints`, `DropLocations`, `GridOrigin`) dibuat otomatis oleh `World.ensure()`
jika belum ada. Pindahkan `GridOrigin` / `Checkpoint1` / `Drop1` ke posisi yang kamu mau, atau tambah BasePart lain
di `Checkpoints` dan `DropLocations` (namanya muncul sebagai pilihan di UI).

## Pasang

**Cara 1: Rojo (disarankan)**
```
rojo serve   # lalu Connect dari plugin Rojo di Studio
```

**Cara 2: manual**
Buat Folder/Script/ModuleScript/LocalScript sesuai tabel di atas. Nama file = nama instance
(`Main.server.lua` -> Script `Main`, `Client.client.lua` -> LocalScript `Client`, sisanya ModuleScript).
Folder `ZidaneSupreme` di ReplicatedStorage harus berisi `Config` dan `Remotes`.

## Cara kerja

- Tiap pemain punya **plot grid sendiri** (`FarmBlocks/<UserId>`), sehingga hit dan drop tidak bentrok antar pemain.
- **Server** memilih mode (`Drop` > `Checkpoint` > `Farm`), memilih block terdekat, memvalidasi jarak dan cooldown, mengurangi HP, dan menjatuhkan drop.
- **Client** hanya menerima tujuan (`Goto`), berjalan dengan `PathfindingService`, dan melapor `PathFailed`. Client tidak bisa memberi damage atau item.
- **Auto Checkpoint**: block tersisa < `Config.Checkpoint.Below` -> jalan ke checkpoint -> **pause** `Wait` detik -> grid diisi ulang -> **resume**.
- **Auto Drop Seed**: Seed >= `SeedDropAt` dan tidak ada ruang untuk 1 Seed lagi -> jalan ke lokasi drop -> hanya Seed dijatuhkan (Gem/Block aman).
- **Kepemilikan drop**: attribute `Owner` + folder per pemain; `Drops.collect` hanya membaca drop milik sendiri.
- Mati/respawn: target dilepas dan dipilih ulang setelah respawn. Pathfinding gagal: block di-skip, checkpoint/drop gagal 3x -> Stop otomatis.
- Semua loop berhenti lewat Stop, Start ulang (token), atau pemain keluar.

## Konfigurasi

Semua angka ada di `Config.lua` (ukuran grid, HP, damage, kapasitas inventory, batas checkpoint, dll).
Catatan: dengan `Inventory.Slots = 3` dan stack Seed 200, kondisi "inventory penuh" tercapai setelah Gem dan Block
masing-masing memakai 1 slot. Ubah `Slots` / `Stack` sesuai desain gamemu.

## Tes

Paste `tests/InventoryCheck.lua` ke Command Bar saat game berjalan (server context). Harus mencetak `Inventory check OK`.

## GitHub

```
git init
git add .
git commit -m "ZIDANE SUPREME v1.1"
git branch -M main
git remote add origin https://github.com/<user>/<repo>.git
git push -u origin main
```

## Soal `loadstring(game:HttpGet(...))`

`game:HttpGet` dan `loadstring` dari URL adalah API executor, tidak tersedia di script game Roblox biasa
(`HttpService:GetAsync` memang ada, tapi menjalankan kode dari internet itu tidak aman dan tidak dianjurkan).
Untuk game sendiri, distribusi lewat GitHub + Rojo (atau model/plugin Roblox) adalah jalur yang benar.
