-- StarterPlayerScripts/ZidaneSupreme/UI (ModuleScript)
-- UI gaming gelap + sidebar. UI hanya MENAMPILKAN state dari server dan mengirim Command; tidak menyimpan state sendiri.
local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")

local UI = {}

local BG, PANEL = Color3.fromRGB(13, 13, 21), Color3.fromRGB(26, 26, 40)
local ACCENT, TEXT, MUTED = Color3.fromRGB(139, 92, 246), Color3.fromRGB(236, 236, 246), Color3.fromRGB(125, 125, 150)
local OK, BAD = Color3.fromRGB(52, 211, 153), Color3.fromRGB(239, 68, 68)

local function new(class, props, parent)
	local i = Instance.new(class)
	for k, v in props do i[k] = v end
	i.Parent = parent
	return i
end

local function round(i, r)
	new("UICorner", { CornerRadius = UDim.new(0, r or 8) }, i)
	return i
end

local function text(parent, t, props)
	local base = {
		Text = t, BackgroundTransparency = 1, TextColor3 = TEXT, Font = Enum.Font.GothamMedium, TextSize = 14,
		Size = UDim2.fromScale(1, 1), TextXAlignment = Enum.TextXAlignment.Left,
	}
	for k, v in props or {} do base[k] = v end
	return new("TextLabel", base, parent)
end

local function button(parent, t, color, props)
	local base = { Text = t, BackgroundColor3 = color, TextColor3 = TEXT, Font = Enum.Font.GothamBold, TextSize = 14, BorderSizePixel = 0 }
	for k, v in props or {} do base[k] = v end
	return round(new("TextButton", base, parent))
end

function UI.build(Remotes, Config)
	local send = function(...) Remotes.Command:FireServer(...) end

	local gui = new("ScreenGui", { Name = "ZidaneSupreme", ResetOnSpawn = false, ZIndexBehavior = Enum.ZIndexBehavior.Sibling },
		Players.LocalPlayer:WaitForChild("PlayerGui"))
	local main = round(new("Frame", {
		Size = UDim2.fromOffset(540, 350), Position = UDim2.fromScale(0.5, 0.5), AnchorPoint = Vector2.new(0.5, 0.5),
		BackgroundColor3 = BG, BorderSizePixel = 0,
	}, gui), 12)
	new("UIStroke", { Color = ACCENT, Thickness = 1.5, Transparency = 0.4 }, main)

	-- header + drag
	local header = new("Frame", { Size = UDim2.new(1, 0, 0, 44), BackgroundTransparency = 1 }, main)
	text(header, Config.Name, { Size = UDim2.new(0.6, 0, 1, 0), Position = UDim2.fromOffset(16, 0), Font = Enum.Font.GothamBlack, TextSize = 18, TextColor3 = ACCENT })
	text(header, Config.Version .. "  |  RightShift = hide", {
		Size = UDim2.new(0.4, -16, 1, 0), Position = UDim2.fromScale(0.6, 0), TextXAlignment = Enum.TextXAlignment.Right, TextColor3 = MUTED, TextSize = 12,
	})
	local dragging, dragStart, startPos
	local function isPointer(i) return i.UserInputType == Enum.UserInputType.MouseButton1 or i.UserInputType == Enum.UserInputType.Touch end
	header.InputBegan:Connect(function(i)
		if isPointer(i) then dragging, dragStart, startPos = true, i.Position, main.Position end
	end)
	UIS.InputChanged:Connect(function(i)
		if dragging and (i.UserInputType == Enum.UserInputType.MouseMovement or i.UserInputType == Enum.UserInputType.Touch) then
			local d = i.Position - dragStart
			main.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + d.X, startPos.Y.Scale, startPos.Y.Offset + d.Y)
		end
	end)
	UIS.InputEnded:Connect(function(i) if isPointer(i) then dragging = false end end)
	UIS.InputBegan:Connect(function(i, gp)
		if not gp and i.KeyCode == Enum.KeyCode.RightShift then gui.Enabled = not gui.Enabled end
	end)

	-- sidebar + pages
	local side = round(new("Frame", { Size = UDim2.new(0, 120, 1, -56), Position = UDim2.fromOffset(10, 46), BackgroundColor3 = PANEL, BorderSizePixel = 0 }, main), 10)
	new("UIListLayout", { Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder }, side)
	new("UIPadding", { PaddingTop = UDim.new(0, 8), PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8) }, side)
	local content = new("Frame", { Size = UDim2.new(1, -150, 1, -56), Position = UDim2.fromOffset(140, 46), BackgroundTransparency = 1 }, main)

	local pages, tabs = {}, {}
	local function show(name)
		for n, f in pages do
			f.Visible = n == name
			tabs[n].BackgroundColor3 = n == name and ACCENT or BG
		end
	end
	local function tab(name)
		local f = new("Frame", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = false }, content)
		new("UIListLayout", { Padding = UDim.new(0, 6) }, f)
		pages[name] = f
		tabs[name] = button(side, name, BG, { Size = UDim2.new(1, 0, 0, 36) })
		tabs[name].Activated:Connect(function() show(name) end)
		return f
	end
	local dash, farm = tab("Dashboard"), tab("Farming")
	show("Dashboard")

	local function row(p, h)
		return round(new("Frame", { Size = UDim2.new(1, 0, 0, h or 30), BackgroundColor3 = PANEL, BorderSizePixel = 0 }, p))
	end
	local function line(p) return text(row(p), "", { Position = UDim2.fromOffset(12, 0), Size = UDim2.new(1, -24, 1, 0) }) end

	-- Dashboard
	local runL, statusL, invL, blocksL = line(dash), line(dash), line(dash), line(dash)
	local ctl = new("Frame", { Size = UDim2.new(1, 0, 0, 40), BackgroundTransparency = 1 }, dash)
	new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 8) }, ctl)
	button(ctl, "START", OK, { Size = UDim2.new(0.5, -4, 1, 0) }).Activated:Connect(function() send("Start") end)
	button(ctl, "STOP", BAD, { Size = UDim2.new(0.5, -4, 1, 0) }).Activated:Connect(function() send("Stop") end)

	-- Farming: toggles (UI hanya berubah setelah server mengonfirmasi lewat State)
	local switches = {}
	local function toggle(labelText, key)
		local r = row(farm)
		text(r, labelText, { Position = UDim2.fromOffset(12, 0), Size = UDim2.new(1, -70, 1, 0) })
		local sw = round(new("TextButton", { Size = UDim2.fromOffset(46, 20), Position = UDim2.new(1, -58, 0.5, -10), Text = "", BackgroundColor3 = MUTED, AutoButtonColor = false }, r), 10)
		local knob = round(new("Frame", { Size = UDim2.fromOffset(16, 16), Position = UDim2.fromOffset(2, 2), BackgroundColor3 = TEXT }, sw), 8)
		local state = false
		sw.Activated:Connect(function() send("Toggle", key, not state) end)
		switches[key] = function(v)
			state = v
			sw.BackgroundColor3 = v and ACCENT or MUTED
			knob.Position = UDim2.fromOffset(v and 28 or 2, 2)
		end
	end
	toggle("Auto Farm", "AutoFarm")
	toggle("Auto Collect", "AutoCollect")
	toggle("Auto Checkpoint", "AutoCheckpoint")
	toggle("Auto Drop Seed", "AutoDrop")

	-- Farming: grid
	local g = Config.Grid
	local gr = row(farm, 36)
	text(gr, "Grid  N x N  /  jarak", { Position = UDim2.fromOffset(12, 0), Size = UDim2.fromOffset(130, 36), TextSize = 13 })
	local function box(x, hint)
		return round(new("TextBox", {
			Size = UDim2.fromOffset(50, 26), Position = UDim2.fromOffset(x, 5), BackgroundColor3 = BG, TextColor3 = TEXT,
			PlaceholderText = hint, Text = "", Font = Enum.Font.GothamMedium, TextSize = 13, ClearTextOnFocus = false, BorderSizePixel = 0,
		}, gr), 6)
	end
	local countBox = box(150, g.MinCount .. "-" .. g.MaxCount)
	local spacingBox = box(206, g.MinSpacing .. "-" .. g.MaxSpacing)
	button(gr, "Apply", ACCENT, { Size = UDim2.fromOffset(64, 26), Position = UDim2.fromOffset(264, 5), TextSize = 13 }).Activated:Connect(function()
		local a, b = tonumber(countBox.Text), tonumber(spacingBox.Text)
		if a and b then send("Grid", a, b) end
	end)

	-- Farming: pilih checkpoint / lokasi drop (klik untuk ganti ke berikutnya)
	local pads = {}
	local function selector(title, folderName, kind)
		local r = row(farm)
		text(r, title, { Position = UDim2.fromOffset(12, 0), Size = UDim2.new(0.5, 0, 1, 0) })
		local btn = button(r, "(default)", BG, { Size = UDim2.new(0.5, -18, 0, 22), Position = UDim2.new(0.5, 6, 0.5, -11), TextSize = 12 })
		btn.Activated:Connect(function()
			local f = workspace:FindFirstChild(folderName)
			if not f then return end
			local names = {}
			for _, c in f:GetChildren() do if c:IsA("BasePart") then table.insert(names, c.Name) end end
			table.sort(names)
			if #names > 0 then send("Pad", kind, names[((table.find(names, btn.Text) or 0) % #names) + 1]) end
		end)
		pads[kind] = btn
	end
	selector("Lokasi Checkpoint", "Checkpoints", "Checkpoint")
	selector("Lokasi Drop", "DropLocations", "DropLocation")

	local function update(st)
		runL.Text = st.Running and "STATUS: RUNNING" or "STATUS: STOPPED"
		runL.TextColor3 = st.Running and OK or BAD
		statusL.Text = "Aktivitas: " .. st.Status
		invL.Text = ("Inventory   Seed %d   Gem %d   Block %d"):format(st.Inv.Seed, st.Inv.Gem, st.Inv.Block)
		blocksL.Text = ("Block tersisa: %d / %d"):format(st.Blocks, st.Total)
		for k, set in switches do set(st.Toggles[k]) end
		if not countBox:IsFocused() then countBox.Text = tostring(st.Settings.Count) end
		if not spacingBox:IsFocused() then spacingBox.Text = tostring(st.Settings.Spacing) end
		for kind, btn in pads do btn.Text = st.Settings[kind] or "(default)" end
	end

	return { update = update }
end

return UI
