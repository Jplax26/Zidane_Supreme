-- ServerScriptService/ZidaneSupreme/Blocks (ModuleScript)
-- Grid block per pemain (plot sendiri) + HP + penghancuran. Semua damage hanya lewat Blocks.hit di server.
local Config = require(game:GetService("ReplicatedStorage"):WaitForChild("ZidaneSupreme").Config)
local World = require(script.Parent.World)
local Drops = require(script.Parent.Drops)

local Blocks = {}
local slots = {}

function Blocks.assignSlot(p)
	local i = 0
	while true do -- berhenti pasti: jumlah slot terpakai terbatas
		local used = false
		for _, v in slots do if v == i then used = true break end end
		if not used then break end
		i += 1
	end
	slots[p] = i
end

local function plot(p)
	local name = tostring(p.UserId)
	local f = World.Blocks:FindFirstChild(name)
	if not f then
		f = Instance.new("Folder")
		f.Name = name
		f.Parent = World.Blocks
	end
	return f
end

function Blocks.release(p)
	slots[p] = nil
	local f = World.Blocks:FindFirstChild(tostring(p.UserId))
	if f then f:Destroy() end
end

-- Bangun ulang grid N x N. Return jumlah block (0 jika GridOrigin tidak ada).
function Blocks.build(p, count, spacing)
	local origin = workspace:FindFirstChild("GridOrigin")
	if not origin then return 0 end
	local g = Config.Grid
	local slot = slots[p] or 0
	local base = Vector3.new(
		origin.Position.X + (slot % g.PlotsPerRow) * g.PlotStride,
		origin.Position.Y - origin.Size.Y / 2,
		origin.Position.Z + (slot // g.PlotsPerRow) * g.PlotStride
	)
	local f = plot(p)
	f:ClearAllChildren()
	for i = 0, count - 1 do
		for j = 0, count - 1 do
			local b = Instance.new("Part")
			b.Name, b.Anchored, b.Size = "Block", true, Vector3.one * g.BlockSize
			b.Position = base + Vector3.new(i * spacing, g.BlockSize / 2, j * spacing)
			b.Color, b.Material = Color3.fromRGB(120, 85, 50), Enum.Material.Slate
			b:SetAttribute("HP", Config.Block.HP)
			b:SetAttribute("Owner", p.UserId)
			b.Parent = f
		end
	end
	return count * count
end

function Blocks.count(p) return #plot(p):GetChildren() end

function Blocks.nearest(p, pos, skip)
	local best, bd = nil, math.huge
	for _, b in plot(p):GetChildren() do
		if not (skip[b] and skip[b] > os.clock()) then
			local d = (b.Position - pos).Magnitude
			if d < bd then best, bd = b, d end
		end
	end
	return best
end

-- true jika block hancur. Block harus berada di plot milik p.
function Blocks.hit(p, b, dmg)
	if not b or b.Parent ~= plot(p) then return false end
	local hp = (b:GetAttribute("HP") or 0) - dmg
	if hp > 0 then
		b:SetAttribute("HP", hp)
		b.Transparency = 0.6 * (1 - hp / Config.Block.HP)
		return false
	end
	local pos = b.Position
	b:Destroy()
	for kind, n in Config.Drops do Drops.spawn(p.UserId, pos, kind, n) end
	return true
end

return Blocks
